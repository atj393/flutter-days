package com.example.decision_maker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
